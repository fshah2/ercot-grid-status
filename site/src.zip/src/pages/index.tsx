import React, { useEffect, useMemo, useState } from "react";
import { Layout } from "../components/Layout";
import { StatusTile } from "../components/StatusTile";
import { ChartCard } from "../components/ChartCard";
import { loadAll } from "../lib/data";
import type { FuelMix7d, Forecast7d, GridStressLatest, Load7d, Outages7d, Price7d } from "../lib/types";
import { fmtMoney, fmtNumber, fmtTime } from "../lib/format";
import { LoadChart } from "../components/charts/LoadChart";
import { FuelMixChart } from "../components/charts/FuelMixChart";
import { PriceChart } from "../components/charts/PriceChart";
import { OutagesChart } from "../components/charts/OutagesChart";

type State = {
  load: Load7d;
  forecast: Forecast7d;
  price: Price7d;
  fuelmix: FuelMix7d;
  outages: Outages7d;
  stress: GridStressLatest;
};

export default function HomePage() {
  const [state, setState] = useState<State | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAll()
      .then(setState)
      .catch((e) => setError(String(e?.message ?? e)));
  }, []);

  const computed = useMemo(() => {
    if (!state) return null;

    const latestPrice = state.price.points.length
      ? state.price.points[state.price.points.length - 1].value
      : null;

    const latestFuel = state.fuelmix.points.length
      ? state.fuelmix.points[state.fuelmix.points.length - 1]
      : null;

    const renewPct =
      latestFuel && (latestFuel.renewables + latestFuel.thermal + latestFuel.other) > 0
        ? (latestFuel.renewables / (latestFuel.renewables + latestFuel.thermal + latestFuel.other)) * 100
        : null;

    return { latestPrice, renewPct };
  }, [state]);

    const stressReason = useMemo(() => {
    if (!state) return null;

    const reasons: string[] = [];
    const s = state.stress;

    // Prices (simple + user-friendly)
    if (s.priceStatus === "Spike") reasons.push("Price spike");
    else if (s.priceStatus === "Elevated") reasons.push("High prices");

    // System Lambda (if present in notes)
    const lambdaNote = s.notes.find((n) => /System Lambda is/i.test(n));
    if (lambdaNote) {
      const m = lambdaNote.match(/(\d+(?:\.\d+)?)/);
      const v = m ? Number(m[1]) : NaN;
      if (Number.isFinite(v)) {
        if (v >= 500) reasons.push("Very high system cost");
        else if (v >= 300) reasons.push("High system cost");
      }
    }

    // Demand / outages (only mention if we’re in Watch/Stressed to avoid noise)
    if (s.gridStress !== "Normal") {
      if (s.notes.some((n) => /Demand right now/i.test(n))) reasons.push("High demand");
      if (s.notes.some((n) => /Outages right now/i.test(n))) reasons.push("High outages");
    }

    // Deduplicate while preserving order
    const seen = new Set<string>();
    const uniq = reasons.filter((r) => (seen.has(r) ? false : (seen.add(r), true)));

    if (uniq.length) return uniq.slice(0, 2).join(" + ");
    return s.gridStress === "Normal" ? "Typical conditions" : "Multiple signals";
  }, [state]);


  return (
    <Layout>
      {error && <div className="alert">Error loading data: {error}</div>}
      {!state && !error && <div className="muted">Loading…</div>}

      {state && computed && (
        <>
          <div className="metaRow">
            <div className="muted">
              Last updated: <b>{fmtTime(state.stress.ts)}</b>
            </div>
          </div>

          <div className="tiles">
            <StatusTile
              title="Grid Stress"
              icon="⚡"
              value={state.stress.gridStress}
              subvalue={stressReason ?? "—"}
              tone={
                state.stress.gridStress === "Normal"
                  ? "good"
                  : state.stress.gridStress === "Watch"
                  ? "warn"
                  : "bad"
              }
              tooltipTitle="What does “Grid Stress” mean?"
              tooltipBody={
                <div>
                  <p>
                    This is a simple “how tight is the grid?” label. It’s meant to answer in a few seconds:
                    <b> should I expect the grid to be under strain right now?</b>
                  </p>
                  <p>
                    We look at: <b>prices</b>, <b>demand</b>, <b>outages</b>, and (when available) <b>System Lambda</b>.
                    Higher values usually mean ERCOT is using more expensive or limited resources.
                  </p>
                  <p className="muted">
                    Here’s exactly what went into the latest label:
                  </p>
                  <ul>
                    {state.stress.notes.slice(0, 6).map((n, i) => (
                      <li key={i}>{n}</li>
                    ))}
                  </ul>
                </div>
              }

            />

            <StatusTile
              title="Renewables right now"
              icon="🌬️"
              value={computed.renewPct == null ? "—" : `${computed.renewPct.toFixed(0)}%`}
              subvalue="Share of generation"
              tone="neutral"
              tooltipTitle="What counts as renewables here?"
              tooltipBody={
                <div>
                  <p>
                    This shows the <b>share of generation</b> coming from renewable sources right now.
                    It helps explain why conditions can change quickly (for example, solar drops at sunset).
                  </p>
                  <p>
                    In our chart:
                    <br />
                    <b>Renewables</b> = wind + solar (+ other renewable labels if present)
                    <br />
                    <b>Thermal</b> = everything else grouped together (mostly gas, plus other dispatchable sources)
                  </p>
                  <p className="muted">
                    This is system-wide ERCOT generation — it’s not your home’s exact mix.
                  </p>
                </div>
              }
            />

            <StatusTile
              title="Prices"
              icon="💲"
              value={state.stress.priceStatus}
              subvalue={
                computed.latestPrice == null
                  ? "Latest price unavailable"
                  : `${fmtMoney(computed.latestPrice, 0)} / MWh`
              }
              tone={
                state.stress.priceStatus === "Normal"
                  ? "good"
                  : state.stress.priceStatus === "Elevated"
                  ? "warn"
                  : "bad"
              }
              tooltipTitle="What is a price “spike” here?"
              tooltipBody={
                <div>
                  <p>
                    This is a simple, system-wide real-time price signal.
                    When prices jump, it often means the grid is tighter
                    (high demand, outages, congestion, or less wind/solar).
                  </p>

                  <p>
                    We label prices as:
                    <br />
                    <b>Normal</b>: typical for the last week
                    <br />
                    <b>Elevated</b>: noticeably higher than usual
                    (often around <b>$150/MWh</b> or more)
                    <br />
                    <b>Spike</b>: very high prices
                    (often <b>$300/MWh+</b>, or among the highest of the week)
                  </p>

                  <p className="muted">
                    This is an indicator of grid conditions — your retail
                    electric bill may not change in real time.
                  </p>
                </div>
              }
            />
          </div>

          <div className="grid">
            <ChartCard
              title="Demand (Load) — last 7 days"
              tooltipTitle="Why should I care about demand?"
              tooltipBody={
                <div>
                  <p>
                    This chart shows how much electricity Texans are using. When demand is unusually high,
                    the grid can get tighter—especially if power plants are out or wind/solar are low.
                  </p>
                  <p className="muted">
                    The dashed line (if present) is the best-effort forecast from ERCOT.
                  </p>
                </div>
              }
            >
              <LoadChart load={state.load} forecast={state.forecast} />
            </ChartCard>

            <ChartCard
              title="Fuel mix — last 7 days"
              tooltipTitle="What does this fuel mix chart mean?"
              tooltipBody={
                <div>
                  <p>
                    This is the grid’s “recipe” over time. A bigger renewables area means more wind/solar/hydro.
                    A bigger thermal area means more gas/coal/nuclear.
                  </p>
                  <p className="muted">
                    It can change quickly with weather, time of day, and demand.
                  </p>
                </div>
              }
            >
              <FuelMixChart fuelmix={state.fuelmix} />
            </ChartCard>

            <ChartCard
              title="Real-time price (headline) — last 7 days"
              tooltipTitle="What price is this, exactly?"
              tooltipBody={
                <div>
                  <p>
                    This is a single “headline” real-time price series chosen to be easy to follow
                    (default: <b>HB_NORTH</b>). It helps answer: “Are prices spiking?”
                  </p>
                  <p className="muted">
                    If you prefer a different hub/zone, change it in <code>scripts/src/config.ts</code>.
                  </p>
                </div>
              }
            >
              <PriceChart price={state.price} />
            </ChartCard>

            <ChartCard
              title="Outages — last 7 days"
              tooltipTitle="What are outages in this chart?"
              tooltipBody={
                <div>
                  <p>
                    Outages are power plants (or parts of them) that are unavailable. Higher outages can make the grid tighter.
                  </p>
                  <p className="muted">
                    We aggregate outage-related fields per timestamp. If your dataset schema differs, adjust the backend normalizer.
                  </p>
                </div>
              }
            >
              <OutagesChart outages={state.outages} />
            </ChartCard>
          </div>

          <div className="notes">
            <h3 className="h3">What to remember</h3>
            <ul>
              <li>
                <b>Normal</b> does not mean “no risk,” it means “nothing unusual in these signals.”
              </li>
              <li>
                <b>Watch</b> means one or more signals look unusually high.
              </li>
              <li>
                <b>Stressed</b> means prices spiked or multiple signals are high at once.
              </li>
            </ul>
          </div>
        </>
      )}
    </Layout>
  );
}
