import React from "react";
import type { FuelMix7d } from "../../lib/types";
import { fmtTime, fmtNumber } from "../../lib/format";
import { EChart } from "./EChart";

export function FuelMixChart(props: { fuelmix: FuelMix7d }) {
  const pts = props.fuelmix.points ?? [];

  const option = {
    tooltip: {
      trigger: "axis",
      formatter: (items: any[]) => {
        const ts = items?.[0]?.data?.[0];
        const rows = items
          .map((it) => `${it.marker} ${it.seriesName}: <b>${fmtNumber(it.data[1])}</b> MW`)
          .join("<br/>");
        return `<div><b>${fmtTime(ts)}</b><br/>${rows}</div>`;
      }
    },
    legend: { top: 0 },
    grid: { left: 48, right: 16, top: 36, bottom: 40 },
    xAxis: { type: "time" },
    yAxis: { type: "value", name: "MW" },
    series: [
      {
        name: "Renewables",
        type: "line",
        stack: "total",
        areaStyle: {},
        showSymbol: false,
        data: pts.map((p) => [p.ts, p.renewables])
      },
      {
        name: "Thermal",
        type: "line",
        stack: "total",
        areaStyle: {},
        showSymbol: false,
        data: pts.map((p) => [p.ts, p.thermal])
      },
      {
        name: "Other / Unknown",
        type: "line",
        stack: "total",
        areaStyle: {},
        showSymbol: false,
        data: pts.map((p) => [p.ts, p.other])
      }
    ]
  };

  return <EChart option={option} />;
}
