import dynamic from "next/dynamic";
import React from "react";

// echarts-for-react uses window; we disable SSR
const ReactECharts = dynamic(() => import("echarts-for-react"), { ssr: false });

export function EChart(props: { option: any; height?: number }) {
  return (
    <div style={{ width: "100%", height: props.height ?? 320 }}>
      <ReactECharts option={props.option} style={{ height: "100%", width: "100%" }} />
    </div>
  );
}
