import React from "react";
import type { Price7d } from "../../lib/types";
import { fmtMoney, fmtTime, fmtNumber } from "../../lib/format";
import { EChart } from "./EChart";

export function PriceChart(props: { price: Price7d }) {
  const pts = props.price.points ?? [];

  const option = {
    tooltip: {
      trigger: "axis",
      formatter: (items: any[]) => {
        const ts = items?.[0]?.data?.[0];
        const v = items?.[0]?.data?.[1];
        return `<div><b>${fmtTime(ts)}</b><br/>Price: <b>${fmtMoney(v, 0)}</b> / MWh</div>`;
      }
    },
    grid: { left: 48, right: 16, top: 12, bottom: 40 },
    xAxis: { type: "time" },
    yAxis: { type: "value", name: "$/MWh" },
    series: [
      {
        name: "Price",
        type: "line",
        showSymbol: false,
        data: pts.map((p) => [p.ts, p.value])
      }
    ]
  };

  return <EChart option={option} />;
}
