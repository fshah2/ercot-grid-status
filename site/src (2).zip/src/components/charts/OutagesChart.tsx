import React from "react";
import type { Outages7d } from "../../lib/types";
import { fmtTime, fmtNumber } from "../../lib/format";
import { EChart } from "./EChart";

export function OutagesChart(props: { outages: Outages7d }) {
  const pts = props.outages.points ?? [];

  const option = {
    tooltip: {
      trigger: "axis",
      formatter: (items: any[]) => {
        const ts = items?.[0]?.data?.[0];
        const v = items?.[0]?.data?.[1];
        return `<div><b>${fmtTime(ts)}</b><br/>Outages: <b>${fmtNumber(v)}</b> MW</div>`;
      }
    },
    grid: { left: 48, right: 16, top: 12, bottom: 40 },
    xAxis: { type: "time" },
    yAxis: { type: "value", name: "MW" },
    series: [
      {
        name: "Outages",
        type: "line",
        showSymbol: false,
        data: pts.map((p) => [p.ts, p.value])
      }
    ]
  };

  return <EChart option={option} />;
}
