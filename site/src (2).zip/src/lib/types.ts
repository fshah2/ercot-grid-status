export type Point = { ts: string; value: number };

export type FuelMixPoint = {
  ts: string;
  renewables: number;
  thermal: number;
  other: number;
};

export type Load7d = { meta: Record<string, unknown>; points: Point[] };
export type Forecast7d = { meta: Record<string, unknown>; points: Point[] };
export type Price7d = { meta: Record<string, unknown>; points: Point[] };
export type FuelMix7d = { meta: Record<string, unknown>; points: FuelMixPoint[] };
export type Outages7d = { meta: Record<string, unknown>; points: Point[] };

export type PriceStatus = "Normal" | "Elevated" | "Spike";
export type GridStress = "Normal" | "Watch" | "Stressed";

export type GridStressLatest = {
  ts: string;
  gridStress: GridStress;
  priceStatus: PriceStatus;
  reserveMarginPct?: number;
  notes: string[];
};
